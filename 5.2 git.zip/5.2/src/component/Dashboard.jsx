function Dashboard() {
  return (
    <>
      <h1>ABOUT PAGE</h1>
    </>
  );
}
export default Dashboard;