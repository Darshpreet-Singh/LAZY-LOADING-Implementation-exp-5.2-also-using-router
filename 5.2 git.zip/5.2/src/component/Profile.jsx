function Profile() {
  return (
    <>
      
      <h1>HOME PAGE</h1>
      <p>Th is the page that shws basic info </p>
    </>
  );
}

export default Profile;